<?php

$con = mysqli_connect("localhost","root","","forum") or die("Some error occurred during connection " . mysqli_error($con));  
$result=mysqli_query($con,"select * from curl");

    while ($row = $result->fetch_assoc()) 
	{
//		file_get_contents($row['newurl']);


		$timeout = 0;
		$ch = curl_init();
		// set cURL options
		$opts = array(CURLOPT_RETURNTRANSFER => true, // do not output to browser
					CURLOPT_URL => $row['newurl'],            // set URL
					CURLOPT_NOBODY => true,         // do a HEAD request only
					CURLOPT_TIMEOUT => $timeout);   // set timeout
		curl_setopt_array($ch, $opts);
		curl_exec($ch); // do it!
		$status = curl_getinfo($ch, CURLINFO_HTTP_CODE); // find HTTP status
		curl_close($ch); // close handle
		//echo $status."<br>"; //or return $status;
			//example checking
			//if ($status == '302') { echo 'HEY, redirection';}


		$result1=mysqli_query($con,"update curl set result='".$status."' where id='".$row['id']."'");
    }

?>